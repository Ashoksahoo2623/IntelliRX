$(document).ready(function () {
    // Autocomplete Search
    const medicines = ["Aspirin", "Ibuprofen", "Paracetamol", "Amoxicillin", "Metformin", "Losartan", "Omeprazole", "Atorvastatin", "Cetirizine", "Albuterol"];
    $(".search-box").on("input", function () {
        let input = $(this).val().toLowerCase();
        let suggestionsBox = $(".suggestions");
        suggestionsBox.empty();

        if (input.length > 0) {
            let filtered = medicines.filter(med => med.toLowerCase().startsWith(input));
            filtered.forEach(med => {
                let div = $("<div>").text(med).on("click", function () {
                    window.location.href = "medicine.html?name=" + encodeURIComponent(med);
                });
                suggestionsBox.append(div);
            });
            suggestionsBox.show();
        } else {
            suggestionsBox.hide();
        }
    });

    // Logout Popup
    $(".logout-btn").click(function () {
        $(".logout-popup").css("bottom", "64px");
    });

    $("#confirm-logout").click(function () {
        $(".logout-popup").css("bottom", "-100px");
        setTimeout(function () {
            window.location.href = "index.html";
        }, 500);
    });

    $("#cancel-logout").click(function () {
        $(".logout-popup").css("bottom", "-150px");
    });

    // Full Menu
    $(".nav-item i.fa-user").parent().click(function () {
        $("#fullMenu").fadeIn();
    });

    $("#closeMenu").click(function () {
        $("#fullMenu").fadeOut();
    });

    // OTP Popup
    $("#send-otp").click(function () {
        $(".otp-popup").css("bottom", "70px");
    });

    $("#close-popup").click(function () {
        $(".otp-popup").css("bottom", "-100px");
        setTimeout(function () {
            window.location.href = "pharmacy.html";
        }, 500);
    });
});

// Login Page Logic

document.addEventListener("DOMContentLoaded", function () {
    const loginBtn = document.querySelector(".login-btn");
    const alertBox = document.getElementById("customAlert");
    const alertMsg = document.getElementById("alertMessage");

    if (loginBtn) {
        function showAlert(message) {
            if (alertBox && alertMsg) {
                alertMsg.innerText = message;
                alertBox.style.display = "block";

                setTimeout(() => {
                    alertBox.style.display = "none";
                }, 5000);
            } else {
                console.warn("Custom alert elements not found.");
            }
        }

        loginBtn.addEventListener("click", function (e) {
            e.preventDefault();

            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();

            if (!email || !password) {
                showAlert("Email and password cannot be blank.");
                return;
            }

            if (email === "admin@intellirx.com" && password === "DietCokeNoIce100ML") {
                window.location.href = "home.html";
            } else {
                showAlert("Incorrect email or password.");
            }
        });
    }
});

// Medicine Page Rendering
$(document).ready(function () {
    const urlParams = new URLSearchParams(window.location.search);
    const medicineName = urlParams.get("name") || "Atorvastatin";
    const pharmacyName = urlParams.get("name") || "Pharmacy";
    const medicineNameFromPharmacy = urlParams.get("medicine") || "Atorvastatin";

    $("#medicine-name").text(medicineName);
    $("#pharmacy-name").text(pharmacyName);
    $("#medicine-name").text(medicineNameFromPharmacy);
    $("#medicine-price").text("$20.00");

    const pharmacies = [
        { name: "CVS Pharmacy", price: "$10.99", link: "pharmacy.html?name=CVS", img: "images/Group 2632.png" },
        { name: "Walgreens", price: "$9.99", link: "pharmacy.html?name=Walgreens", img: "images/Group 2633.png" },
        { name: "Rite Aid", price: "$11.49", link: "pharmacy.html?name=RiteAid", img: "images/Group 2634.png" },
        { name: "Walmart Pharmacy", price: "$8.99", link: "pharmacy.html?name=Walmart", img: "images/Group 2635.png" }
    ];

    pharmacies.forEach(pharmacy => {
        $(".pharmacy-list").append(
            `<div class='pharmacy-item' onclick='location.href="${pharmacy.link}"'>
                <div class='pharmacy-first-item'>
                    <img src="${pharmacy.img}" alt="${pharmacy.name}" style="height: 30px;">
                    <div>
                        <p class='pharmacy-name'>${pharmacy.name}</p>
                        <p class='pharmacy-price'>${pharmacy.price}</p>
                    </div>
                </div>
                <i class="fa-solid fa-chevron-right"></i>
            </div>`
        );
    });

    // Text button click for redirect
    $(".text-btn").click(function () {
        const pharmacyName = urlParams.get("name") || "Pharmacy";
        const medicineName = urlParams.get("medicine") || "Atorvastatin";
        window.location.href = `text-verification.html?name=${pharmacyName}&medicine=${medicineName}`;
    });
});
